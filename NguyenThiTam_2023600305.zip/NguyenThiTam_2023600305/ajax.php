<?php
    $name = $_REQUEST['name'];
    $year = $_REQUEST['year'];
    echo "<div>".$name." sinh nam ".$year."</div>";
?>