<?php
    header("Content-type: application/json");
    $students = [
        [
            "username" => "teonv",
            "fullname" => "Nguyễn Văn Tèo",
            "email" => "teonv@fpt.edu.vn",
            "gender" => true,
            "birthday" => "1995-12-21",
            "schoolfee" => "1500000",
            "marks" => "0",
        ],
        [
            "username" => "tinhv",
            "fullname" => "Hoàng Văn Tí",
            "email" => "tinhv@fpt.edu.vn",
            "gender" => false,
            "birthday" => "1998-06-15",
            "schoolfee" => "1800000",
            "marks" => "8.5",
        ]
        ];
        echo json_encode($students, JSON_PRETTY_PRINT);
?>