<?php
    $u = $_REQUEST['u'];
    $p = $_REQUEST['p'];
    $arr = ["teo", "ti"];
    if(in_array($u, $arr) == false) echo "Username không tồn tại";
    else if($p != "1") echo "Password không đúng";
    else echo "Đăng nhập thành công";0
?>